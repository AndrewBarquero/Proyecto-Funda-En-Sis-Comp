# ============================================================
# StrangerTEC - Morse Translator
# Interfaz gráfica para PC (Python + Tkinter)
#
# Este archivo corre en la computadora y se encarga de:
#   - Seleccionar palabras y enviarlas a la maqueta vía WiFi
#   - Modo Transmisión Simple: 3 fases con velocidades crecientes
#   - Modo VS: Jugador A (teclado) vs Jugador B (botón en maqueta)
#   - Guardar puntajes y mostrar Top 10
# ============================================================

import tkinter as tk
from tkinter import messagebox
try:
    from PIL import Image, ImageTk
    PIL_DISPONIBLE = True
except ImportError:
    PIL_DISPONIBLE = False

import random
import socket
import threading
import time


# ============================================================
# CONFIGURACIÓN DE RED
# ============================================================
SERVER_IP = '10.21.55.165'   # IP de la Raspberry Pi Pico W (ver consola al arrancar)
PORT      = 1717              # Puerto TCP (debe coincidir con main.py)


# ============================================================
# SOCKET Y ESTADO DE CONEXIÓN
# ============================================================
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
conectado     = False


# ============================================================
# DICCIONARIO MORSE (código → letra, para decodificar)
# ============================================================
morse_diccionario = {
    ".-":   "A",  "-...": "B",  "-.-.": "C",  "-..":  "D",
    ".":    "E",  "..-.": "F",  "--.":  "G",  "....": "H",
    "..":   "I",  ".---": "J",  "-.-":  "K",  ".-..": "L",
    "--":   "M",  "-.":   "N",  "---":  "O",  ".--.": "P",
    "--.-": "Q",  ".-.":  "R",  "...":  "S",  "-":    "T",
    "..-":  "U",  "...-": "V",  ".--":  "W",  "-..-": "X",
    "-.--": "Y",  "--..": "Z"
}

# Variable global: acumula el Morse que envía el jugador B desde la maqueta
morse_jugador_B = ""


# ============================================================
# HILO DE RECEPCIÓN (lee mensajes que llegan desde la maqueta)
# ============================================================
def receive_messages():
    """
    Corre en un hilo separado.
    Recibe los símbolos Morse que el jugador B envía con su botón
    y los acumula en morse_jugador_B.
    El jugador B envía: "." (punto), "-" (raya), "_" (sep. letra)
    """
    global morse_jugador_B
    while True:
        try:
            msg = client_socket.recv(1024).decode()
            if msg:
                morse_jugador_B += msg
                print("Jugador B →", morse_jugador_B)
        except:
            break


# ============================================================
# CONECTAR AL SERVIDOR DE LA MAQUETA
# ============================================================
def connect():
    """
    Intenta conectar al servidor TCP de la Raspberry Pi Pico W.
    Si falla, marca conectado = False y el juego puede usarse
    sin maqueta (para pruebas de la interfaz).
    """
    global conectado
    try:
        client_socket.connect((SERVER_IP, PORT))
        conectado = True
        threading.Thread(target=receive_messages, daemon=True).start()
        print("Conectado a la Raspberry Pi Pico W")
    except Exception as e:
        conectado = False
        print(f"Sin conexión con la maqueta: {e}")


# ============================================================
# HELPER: ENVIAR COMANDO A LA MAQUETA
# ============================================================
def enviar(cmd_bytes):
    """Envía bytes a la maqueta. No hace nada si no hay conexión."""
    if conectado:
        try:
            client_socket.send(cmd_bytes)
        except Exception as e:
            print("Error al enviar:", e)


# ============================================================
# HELPER: TRADUCIR MORSE A TEXTO
# ============================================================
def traducir_morse(codigo):
    """
    Convierte una cadena Morse a texto.
    Los símbolos de cada letra están separados por "_".
    Ejemplo: ".-_-..._.-" → "ABA"
    Letras no reconocidas se omiten.
    """
    if not codigo:
        return ""
    palabra = ""
    letras  = codigo.split("_")
    for letra in letras:
        letra = letra.strip()
        if letra in morse_diccionario:
            palabra += morse_diccionario[letra]
    return palabra


# ============================================================
# TOP 10 PUNTAJES
# ============================================================
def mostrar_top10(parent):
    """
    Lee 'puntajes.txt', ordena de mayor a menor y muestra los
    primeros 10 en una ventana emergente.
    """
    ventana_top = tk.Toplevel(parent)
    ventana_top.title("🏆 Top 10 Puntajes")
    ventana_top.geometry("300x380+700+200")
    ventana_top.resizable(False, False)

    tk.Label(
        ventana_top,
        text="🏆 Top 10 Puntajes",
        font=("Arial", 14, "bold")
    ).pack(pady=12)

    try:
        with open("puntajes.txt", "r", encoding="utf-8") as f:
            lineas = f.readlines()

        # Parsear líneas "nombre,puntaje"
        puntajes = []
        for linea in lineas:
            partes = linea.strip().split(",")
            if len(partes) >= 2:
                try:
                    puntajes.append((partes[0], int(partes[1])))
                except ValueError:
                    pass   # línea mal formada → ignorar

        # Ordenar descendente y tomar los 10 mejores
        puntajes.sort(key=lambda x: x[1], reverse=True)
        top10 = puntajes[:10]

        if not top10:
            tk.Label(ventana_top, text="Aún no hay puntajes.").pack(pady=20)
        else:
            for pos, (nombre, pts) in enumerate(top10, start=1):
                medalla = "🥇" if pos == 1 else ("🥈" if pos == 2 else ("🥉" if pos == 3 else f"{pos}. "))
                tk.Label(
                    ventana_top,
                    text=f"{medalla} {nombre}  —  {pts} pts",
                    font=("Arial", 11)
                ).pack(anchor="w", padx=30, pady=1)

    except FileNotFoundError:
        tk.Label(
            ventana_top,
            text="No hay puntajes guardados aún.\nJuega y guarda tu nombre.",
            font=("Arial", 10)
        ).pack(pady=20)

    tk.Button(
        ventana_top,
        text="Cerrar",
        bg="RoyalBlue4",
        fg="White",
        command=ventana_top.destroy
    ).pack(pady=15)


# ============================================================
# VENTANA PRINCIPAL
# ============================================================
ventana_principal = tk.Tk()
ventana_principal.title("StrangerTEC – Morse Translator")
ventana_principal.geometry("575x425+650+200")
ventana_principal.resizable(False, False)

# Intentar cargar imagen de fondo; si no existe, usar fondo negro
if PIL_DISPONIBLE:
    try:
        imagen1   = Image.open("Pantalla principal.PNG")
        imagen_tk = ImageTk.PhotoImage(imagen1)
        imagen_inicio = tk.Label(ventana_principal, image=imagen_tk)
        imagen_inicio.pack()
    except FileNotFoundError:
        imagen_inicio = tk.Label(ventana_principal, bg="black",
                                 text="StrangerTEC", fg="red",
                                 font=("Arial", 28, "bold"))
        imagen_inicio.pack(expand=True, fill="both")
else:
    imagen_inicio = tk.Label(ventana_principal, bg="black",
                             text="StrangerTEC", fg="red",
                             font=("Arial", 28, "bold"))
    imagen_inicio.pack(expand=True, fill="both")


# ============================================================
# CIERRE SEGURO
# CORRECCIÓN: el original tenía una función anidada que nunca
# se ejecutaba, por lo que la ventana nunca cerraba realmente.
# ============================================================
def cerrar_todo():
    """Envía OFF a la maqueta, cierra el socket y destruye la ventana."""
    try:
        if conectado:
            client_socket.send(b"OFF")
            client_socket.close()
    except:
        pass
    ventana_principal.destroy()

ventana_principal.protocol("WM_DELETE_WINDOW", cerrar_todo)


# ============================================================
# SELECCIÓN DE MODOS
# ============================================================
def modo_de_juego():
    ventana_principal.withdraw()

    ventana_juego1 = tk.Toplevel(ventana_principal)
    ventana_juego1.title("Modos de juego")
    ventana_juego1.geometry("515x375+675+250")
    ventana_juego1.resizable(False, False)

    # ===========================================================
    # MODO TRANSMISIÓN SIMPLE
    # ===========================================================
    def transmision():
        """
        El jugador escucha la palabra en Morse desde la maqueta,
        la escribe en el PC y recibe un puntaje.
        Se juegan 3 fases con velocidades crecientes.
        """
        ventana_juego1.withdraw()

        ventana_t = tk.Toplevel(ventana_principal)
        ventana_t.title("Modo Transmisión Simple")
        ventana_t.geometry("500x430+650+200")
        ventana_t.resizable(False, False)

        # Etiqueta de estado: instrucciones y puntaje en tiempo real
        texto_juego = tk.Label(
            ventana_t,
            text="Presiona  'Siguiente fase'  para comenzar la Fase 1.\n"
                 "Escucha el Morse y escribe la palabra debajo.",
            bg="RoyalBlue4",
            fg="White",
            font=("Arial", 10, "bold"),
            wraplength=460,
            justify="center",
            height=4
        )
        texto_juego.pack(pady=20)

        # Palabras candidatas (máx 16 caracteres, sin espacios)
        palabras = [
            "SOS", "NO", "SI", "CAJA", "GATO", "SOL", "RATON",
            "LAPIZ", "ZAPATO", "RELOJ", "REGLA", "HORROR", "BOMBA",
            "TRAMPA", "PANTALLA", "CELULAR", "SIETE", "GRANDE",
            "CABALLO", "SAL", "MANGO", "FOTO", "AZUL", "ARBOL"
        ]

        # Configuración de las 3 fases
        fases = [
            {"num": 1, "msg": "FASE 1 — Velocidad normal",  "pts_letra": 10},
            {"num": 2, "msg": "FASE 2 — Más rápido",        "pts_letra": 15},
            {"num": 3, "msg": "FASE 3 — Máxima velocidad",  "pts_letra": 20},
        ]

        # Estado mutable del juego (usamos dict para evitar problemas de scope)
        estado = {
            "fase_idx":     0,     # índice de la fase actual (0-2)
            "palabra":      "",    # palabra enviada a la maqueta
            "puntaje":      0,     # puntaje acumulado
        }

        # Campo donde el jugador escribe su respuesta
        tk.Label(ventana_t, text="Escribe la palabra que escuchaste:").pack()
        entrada = tk.Entry(ventana_t, width=22, font=("Arial", 12))
        entrada.pack(pady=6)

        # Etiqueta de puntaje en tiempo real
        lbl_puntaje = tk.Label(
            ventana_t,
            text="Puntaje acumulado: 0 pts",
            font=("Arial", 10)
        )
        lbl_puntaje.pack(pady=4)

        # -------------------------------------------------------
        # Avanzar a la siguiente fase (botón "Siguiente fase")
        # -------------------------------------------------------
        def siguiente_fase():
            idx = estado["fase_idx"]

            if idx >= len(fases):
                # Ya se jugaron las 3 fases → mostrar resultado final
                texto_juego.config(
                    text=f"¡Partida terminada!\n"
                         f"Puntaje final: {estado['puntaje']} pts\n"
                         f"Guarda tu nombre para el Top 10."
                )
                pedir_nombre()
                return

            fase = fases[idx]

            # Informar al jugador qué fase viene
            texto_juego.config(
                text=f"{fase['msg']}\n"
                     f"Puntaje acumulado: {estado['puntaje']} pts\n"
                     f"Enviando palabra a la maqueta..."
            )
            ventana_t.update()

            # CORRECCIÓN: formato correcto es "FASE1", "FASE2", "FASE3"
            # (el original enviaba "FASE:{n}" con dos puntos)
            enviar(f"FASE{fase['num']}".encode())
            time.sleep(0.4)   # pausa para que la Pico procese el comando

            # Seleccionar palabra aleatoria y enviarla sin prefijo
            # CORRECCIÓN: el original enviaba "PALABRA:{word}" pero la Pico
            # no tiene ese prefijo → intentaba mostrar "PALABRA:GATO" completo
            estado["palabra"] = random.choice(palabras)
            entrada.delete(0, tk.END)   # limpiar campo de respuesta

            enviar(estado["palabra"].encode())   # enviar solo la palabra

            texto_juego.config(
                text=f"{fase['msg']}\n"
                     f"Escucha el Morse y escribe la palabra.\n"
                     f"Puntaje acumulado: {estado['puntaje']} pts"
            )
            estado["fase_idx"] += 1   # avanzar índice para la próxima vez

        # -------------------------------------------------------
        # Calcular puntaje de la fase recién escuchada
        # -------------------------------------------------------
        def calcular_puntaje():
            idx    = estado["fase_idx"]   # ya fue incrementado → 1, 2 o 3
            palabra = estado["palabra"]
            respuesta = entrada.get().strip().upper()

            if not palabra:
                messagebox.showinfo(
                    "Espera",
                    "Primero presiona 'Siguiente fase' para recibir una palabra."
                )
                return

            # CORRECCIÓN: el original calculaba fase = fase_actual - 1
            # y luego comparaba con 1, 2, 3 → siempre daba 0 porque idx-1
            # resultaba en 0, 1, 2 respectivamente. Ahora usamos idx directamente.
            pts_letra = fases[idx - 1]["pts_letra"] if 1 <= idx <= 3 else 10

            puntaje_fase = 0
            for i in range(min(len(palabra), len(respuesta))):
                if palabra[i] == respuesta[i]:
                    puntaje_fase += pts_letra

            estado["puntaje"] += puntaje_fase
            lbl_puntaje.config(text=f"Puntaje acumulado: {estado['puntaje']} pts")

            resultado = f"Palabra correcta: {palabra}\n" \
                        f"Tu respuesta:     {respuesta}\n" \
                        f"Puntaje esta fase: {puntaje_fase} pts  " \
                        f"(+{pts_letra} por letra correcta)\n" \
                        f"Puntaje total:     {estado['puntaje']} pts"

            if idx < len(fases):
                resultado += "\n\nPresiona 'Siguiente fase' para continuar."
            else:
                resultado += "\n\nPresiona 'Siguiente fase' para ver el resultado final."

            texto_juego.config(text=resultado)

        # -------------------------------------------------------
        # Pedir nombre y guardar puntaje al terminar las 3 fases
        # -------------------------------------------------------
        def pedir_nombre():
            ventana_nombre = tk.Toplevel(ventana_t)
            ventana_nombre.title("Guardar puntaje")
            ventana_nombre.geometry("320x200+500+400")
            ventana_nombre.resizable(False, False)

            tk.Label(
                ventana_nombre,
                text=f"¡Partida terminada!\nPuntaje final: {estado['puntaje']} pts",
                font=("Arial", 12, "bold")
            ).pack(pady=10)

            tk.Label(ventana_nombre, text="Ingresa tu nombre:").pack()
            entrada_nombre = tk.Entry(ventana_nombre, width=22)
            entrada_nombre.pack(pady=5)
            entrada_nombre.focus()

            def guardar():
                nombre = entrada_nombre.get().strip()
                if not nombre:
                    messagebox.showwarning("Nombre vacío",
                                           "Por favor ingresa un nombre.")
                    return

                # Guardar en archivo de texto (nombre,puntaje)
                with open("puntajes.txt", "a", encoding="utf-8") as f:
                    f.write(f"{nombre},{estado['puntaje']}\n")

                ventana_nombre.destroy()
                mostrar_top10(ventana_t)   # mostrar Top 10 al guardar

            tk.Button(
                ventana_nombre,
                text="Guardar y ver Top 10",
                bg="RoyalBlue4",
                fg="White",
                command=guardar
            ).pack(pady=10)

        # -------------------------------------------------------
        # Volver al menú de modos
        # -------------------------------------------------------
        def volver_t():
            enviar(b"OFF")
            ventana_t.destroy()
            ventana_juego1.deiconify()

        ventana_t.protocol("WM_DELETE_WINDOW", volver_t)

        # Botones de la pantalla de transmisión
        tk.Button(
            ventana_t,
            text="▶  Siguiente fase",
            bg="RoyalBlue4",
            fg="White",
            width=20,
            font=("Arial", 10),
            command=siguiente_fase
        ).pack(pady=4)

        tk.Button(
            ventana_t,
            text="✔  Calcular puntaje",
            bg="DarkGreen",
            fg="White",
            width=20,
            font=("Arial", 10),
            command=calcular_puntaje
        ).pack(pady=4)

        tk.Button(
            ventana_t,
            text="🏆  Ver Top 10",
            bg="goldenrod4",
            fg="White",
            width=20,
            font=("Arial", 10),
            command=lambda: mostrar_top10(ventana_t)
        ).pack(pady=4)

        tk.Button(
            ventana_t,
            text="← Volver",
            bg="gray30",
            fg="White",
            width=20,
            font=("Arial", 10),
            command=volver_t
        ).pack(pady=4)

    # ===========================================================
    # MODO ESCUCHA Y TRANSMISIÓN (VS)
    # ===========================================================
    def modo_vs():
        """
        Modo de dos jugadores:
          - Jugador A usa la tecla SPACE del teclado.
          - Jugador B usa el botón físico en la maqueta.
        Ambos escuchan/ven la misma palabra y la transcriben en Morse.
        Gana quien tenga más letras correctas.
        """
        ventana_juego1.withdraw()

        ventana_vs = tk.Toplevel(ventana_principal)
        ventana_vs.title("Modo Escucha vs Transmisión")
        ventana_vs.geometry("530x500+650+200")
        ventana_vs.resizable(False, False)

        texto = tk.Label(
            ventana_vs,
            text="Presiona  Start  para comenzar la partida.",
            font=("Arial", 11, "bold"),
            bg="RoyalBlue4",
            fg="White",
            width=55,
            height=6,
            wraplength=490,
            justify="center"
        )
        texto.pack(pady=15)

        # Palabras para el modo VS (cortas, buenas para Morse)
        palabras_vs = [
            "CASA", "CASCO", "CARTA", "CORTA", "GATO", "PATO",
            "RATA", "LATA", "MANGO", "MANDO", "SALA", "SAL",
            "SOL", "ROL", "MOTOR", "MORTAL", "CABLE", "CALLE",
            "BOMBA", "VOLTAJE", "RATON", "LIBRO"
        ]

        # Estado del modo VS
        estado_vs = {
            "palabra":      "",    # palabra seleccionada para esta ronda
            "morse_A":      "",    # Morse que ingresó el jugador A (teclado)
            "t_inicio":     0.0,   # marca de tiempo para SPACE
        }

        # Limpiar Morse del jugador B al entrar
        global morse_jugador_B
        morse_jugador_B = ""

        # -------------------------------------------------------
        # Captura de la tecla SPACE (jugador A)
        # -------------------------------------------------------
        def space_presionado(event):
            estado_vs["t_inicio"] = time.time()

        def space_soltado(event):
            duracion = time.time() - estado_vs["t_inicio"]

            if duracion < 0.5:
                estado_vs["morse_A"] += "."     # presión corta → punto
            elif duracion < 1.5:
                estado_vs["morse_A"] += "-"     # presión media → raya
            else:
                estado_vs["morse_A"] += "_"     # presión larga → sep. letra

            texto.config(
                text=f"Jugador A — Morse ingresado:\n{estado_vs['morse_A']}\n\n"
                     f"(SPACE: corto=punto  medio=raya  largo=separador)"
            )

        ventana_vs.bind("<KeyPress-space>",   space_presionado)
        ventana_vs.bind("<KeyRelease-space>", space_soltado)

        # -------------------------------------------------------
        # Iniciar partida
        # -------------------------------------------------------
        def iniciar():
            global morse_jugador_B

            # Reiniciar entradas
            estado_vs["morse_A"] = ""
            morse_jugador_B      = ""
            estado_vs["palabra"] = random.choice(palabras_vs)

            texto.config(
                text="La maqueta mostrará/sonará la palabra...\n"
                     "Ambos jugadores presten atención."
            )

            # CORRECCIÓN: el original nunca enviaba MODO=VS
            # → la Pico nunca aceptaba el botón del jugador B.
            enviar(b"MODO=VS")
            time.sleep(0.1)

            # Turno A primero: el botón físico queda deshabilitado
            enviar(b"TURNO=A")
            time.sleep(0.1)

            # Enviar solo la palabra (sin prefijo "PALABRA:")
            # CORRECCIÓN: el original enviaba "PALABRA:GATO" pero la Pico
            # lo mostraba como texto completo.
            enviar(estado_vs["palabra"].encode())

            # Indicar al jugador A que puede empezar a ingresar
            ventana_vs.after(
                2000,
                lambda: texto.config(
                    text=f"Jugador A: usa SPACE para ingresar tu Morse.\n"
                         f"Morse A: {estado_vs['morse_A']}\n\n"
                         f"Cuando termines, presiona 'Jugador A terminó'."
                )
            )

        # -------------------------------------------------------
        # Jugador A terminó → habilitar botón de B
        # -------------------------------------------------------
        def turno_jugador_B():
            global morse_jugador_B
            morse_jugador_B = ""   # limpiar morse previo de B

            texto.config(
                text="Turno del Jugador B.\n"
                     "Usa el botón físico en la maqueta para ingresar Morse.\n\n"
                     "corto=punto  •  largo=raya  •  muy largo=sep. letra\n\n"
                     "Cuando B termine, presiona 'Evaluar resultado'."
            )

            # CORRECCIÓN: el original enviaba b"TURNO_B" (sin signo igual)
            # → la Pico buscaba "TURNO=" y nunca lo procesaba.
            # También estaba fuera del bloque "if conectado:" → crash sin red.
            enviar(b"TURNO=B")

        # -------------------------------------------------------
        # Evaluar y mostrar resultados
        # -------------------------------------------------------
        def evaluar():
            global morse_jugador_B

            # Terminar el loop de escucha del botón en la Pico
            # CORRECCIÓN: sin este envío, la Pico quedaba esperando
            # input de B para siempre (loop escuchar_boton_B).
            enviar(b"END_B")
            time.sleep(0.1)
            enviar(b"MODO=NORMAL")   # restaurar modo normal en la Pico

            palabra   = estado_vs["palabra"]
            texto_A   = traducir_morse(estado_vs["morse_A"])
            texto_B   = traducir_morse(morse_jugador_B)

            if not palabra:
                texto.config(text="Primero inicia la partida (Start).")
                return

            # Contar letras correctas para cada jugador
            puntos_A = sum(
                1 for i in range(min(len(texto_A), len(palabra)))
                if texto_A[i] == palabra[i]
            )
            puntos_B = sum(
                1 for i in range(min(len(texto_B), len(palabra)))
                if texto_B[i] == palabra[i]
            )

            if puntos_A > puntos_B:
                ganador = "🏆 ¡GANA JUGADOR A!"
            elif puntos_B > puntos_A:
                ganador = "🏆 ¡GANA JUGADOR B!"
            else:
                ganador = "🤝 ¡EMPATE!"

            texto.config(
                text=f"Palabra original:  {palabra}\n\n"
                     f"Jugador A morse:   {estado_vs['morse_A']}\n"
                     f"Jugador A leyó:    {texto_A}  ({puntos_A} correctas)\n\n"
                     f"Jugador B morse:   {morse_jugador_B}\n"
                     f"Jugador B leyó:    {texto_B}  ({puntos_B} correctas)\n\n"
                     f"{ganador}"
            )

        # -------------------------------------------------------
        # Volver al menú de modos
        # -------------------------------------------------------
        def volver_vs():
            enviar(b"END_B")
            enviar(b"MODO=NORMAL")
            enviar(b"OFF")
            ventana_vs.destroy()
            ventana_juego1.deiconify()

        ventana_vs.protocol("WM_DELETE_WINDOW", volver_vs)

        # Botones del modo VS
        tk.Button(ventana_vs, text="▶  Start",
                  bg="RoyalBlue4", fg="White", width=28, font=("Arial", 10),
                  command=iniciar).pack(pady=4)

        tk.Button(ventana_vs, text="✔  Jugador A terminó → Turno B",
                  bg="DarkGreen", fg="White", width=28, font=("Arial", 10),
                  command=turno_jugador_B).pack(pady=4)

        tk.Button(ventana_vs, text="📊  Evaluar resultado",
                  bg="purple4", fg="White", width=28, font=("Arial", 10),
                  command=evaluar).pack(pady=4)

        tk.Button(ventana_vs, text="← Volver",
                  bg="gray30", fg="White", width=28, font=("Arial", 10),
                  command=volver_vs).pack(pady=4)

    # ===========================================================
    # FONDO Y BOTONES DEL MENÚ DE MODOS
    # ===========================================================
    if PIL_DISPONIBLE:
        try:
            imagen2  = Image.open("Fondo.PNG")
            fondo_tk = ImageTk.PhotoImage(imagen2)
            fondo    = tk.Label(ventana_juego1, image=fondo_tk)
            fondo.image = fondo_tk
            fondo.pack()
        except FileNotFoundError:
            fondo = tk.Label(ventana_juego1, bg="black",
                             text="StrangerTEC", fg="red",
                             font=("Arial", 18, "bold"))
            fondo.pack(expand=True, fill="both")
    else:
        fondo = tk.Label(ventana_juego1, bg="black",
                         text="StrangerTEC", fg="red",
                         font=("Arial", 18, "bold"))
        fondo.pack(expand=True, fill="both")

    tk.Button(
        fondo, text="Modo Transmisión Simple",
        bg="RoyalBlue4", fg="White", width=24,
        command=transmision
    ).place(relx=0.28, rely=0.35)

    tk.Button(
        fondo, text="Modo Escucha vs Transmisión",
        bg="RoyalBlue4", fg="White", width=26,
        command=modo_vs
    ).place(relx=0.25, rely=0.48)

    tk.Button(
        fondo, text="🏆 Top 10 Puntajes",
        bg="goldenrod4", fg="White", width=20,
        command=lambda: mostrar_top10(ventana_juego1)
    ).place(relx=0.33, rely=0.62)

    tk.Button(
        fondo, text="← Volver",
        bg="gray30", fg="White", width=10,
        command=lambda: (ventana_juego1.destroy(), ventana_principal.deiconify())
    ).place(relx=0.40, rely=0.80)


# ============================================================
# BOTONES DE LA PANTALLA PRINCIPAL
# ============================================================
tk.Button(
    imagen_inicio,
    text="Jugar",
    bg="RoyalBlue4",
    fg="White",
    width=8,
    font=("Arial", 10),
    command=modo_de_juego
).place(relx=0.40, rely=0.45)

tk.Button(
    imagen_inicio,
    text="Top 10",
    bg="goldenrod4",
    fg="White",
    width=8,
    font=("Arial", 10),
    command=lambda: mostrar_top10(ventana_principal)
).place(relx=0.40, rely=0.60)

tk.Button(
    imagen_inicio,
    text="Salir",
    bg="gray30",
    fg="White",
    width=8,
    font=("Arial", 10),
    command=cerrar_todo
).place(relx=0.40, rely=0.80)


# ============================================================
# CONECTAR E INICIAR
# ============================================================
connect()                       # intentar conexión con la maqueta
ventana_principal.mainloop()    # iniciar loop de la UI